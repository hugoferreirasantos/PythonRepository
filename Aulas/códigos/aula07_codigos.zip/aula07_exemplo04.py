'''
Aula07_exemplo04.py
'''
#biblioteca
import sqlite3 as conector #apelido
#função excluir        
def excluir_dados():
    try:
        conexao = conector.connect('meu_banco.db')
        cursor = conexao.cursor()
        #definição do comando
        comando = 'DELETE FROM Pessoa WHERE cpf=12345678900;'
        #execução do comando
        cursor.execute(comando)
        #efetivação do comando
        conexao.commit()
        print('Registro excluído!!!')
    except conector.DatabaseError as err:
        print('Erro de banco de dados: ',err)
    finally:
        #fechamento das conexões
        if(conexao):
            cursor.close()
            conexao.close()
#executar função
excluir_dados()
#encerrando
print("Fim do programa")
