'''
Aula07_exemplo02.py
'''
#biblioteca
import sqlite3 as conector #apelido
#Classe Pessoa
class Pessoa:
    def __init__(self,cpf,nome,data_nascimento,usa_oculos):
        self.cpf = cpf
        self.nome = nome
        self.data_nascimento = data_nascimento
        self.usa_oculos = usa_oculos
        
#função inserir com parâmetros        
def inserir_dados():
    try:
        #abertura da conexão
        conexao = conector.connect('meu_banco.db')
        #aquisição de um cursor
        cursor = conexao.cursor()
        #Criação dos dados de Pessoa
        pessoa = Pessoa(20000000044,'José','1999-11-15',True)
        #definição com query parameter
        sql = '''INSERT INTO Pessoa (cpf, nome, nascimento, oculos)
            VALUES (?,?,?,?);'''
        #execução com parâmetros
        cursor.execute(sql,(pessoa.cpf,pessoa.nome,pessoa.data_nascimento,pessoa.usa_oculos))
        #efetivação do comando
        conexao.commit()
        print('Dados inseridos!!!')
    except conector.DatabaseError as err:
        print('Erro de banco de dados: ',err)
    finally:
        #fechamento das conexões
        if(conexao):
            cursor.close()
            conexao.close()

#executar função
inserir_dados()
#encerrando
print("Fim do programa")
