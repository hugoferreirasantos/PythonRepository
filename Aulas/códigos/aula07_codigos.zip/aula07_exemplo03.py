'''
Aula07_exemplo03.py
'''
#biblioteca
import sqlite3 as conector #apelido
#função alterar        
def alterar_dados():
    try:
        conexao = conector.connect('meu_banco.db')
        cursor = conexao.cursor()
        #definição do comando
        comando1 = 'UPDATE Pessoa SET oculos=1;'
        #execução do comando
        cursor.execute(comando1)
        #definição do comando
        comando2 = 'UPDATE Pessoa SET oculos=? WHERE cpf=10000000099;'
        #execução do comando
        cursor.execute(comando2,(True,))
        #definição do comando
        comando3 = 'UPDATE Pessoa SET oculos=:usa_oculos WHERE cpf=:cpf;'
        #execução do comando
        cursor.execute(comando3, {'usa_oculos':False, 'cpf':20000000044})
        #efetivação do comando
        conexao.commit()
        print('Dados alterados!!!')
    except conector.DatabaseError as err:
        print('Erro de banco de dados: ',err)
    finally:
        #fechamento das conexões
        if(conexao):
            cursor.close()
            conexao.close()
#executar função
alterar_dados()
#encerrando
print("Fim do programa")
