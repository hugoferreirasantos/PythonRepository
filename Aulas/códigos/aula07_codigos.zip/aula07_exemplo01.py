'''
Aula07_exemplo01.py
'''
#biblioteca
import sqlite3 as conector #apelido
def criar_tabela():
    try:
        #abertura da conexão
        conexao = conector.connect('meu_banco.db')
        #aquisição de um cursor
        cursor = conexao.cursor()
        #execução de comandos SQL
        sql1 = '''CREATE TABLE if not exists Pessoa (
            cpf INTEGER NOT NULL,
            nome TEXT NOT NULL,
            nascimento DATE NOT NULL,
            oculos BOOLEAN NOT NULL,
            PRIMARY KEY (cpf));'''
        sql2 = '''CREATE TABLE if not exists Marca (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            sigla CHARACTER(2) NOT NULL);'''
        sql3 = '''CREATE TABLE if not exists Veiculo (
            placa CHARACTER(7) NOT NULL,
            ano INTEGER NOT NULL,
            cor TEXT NOT NULL,
            motor REAL NOT NULL,
            proprietario INTEGER NOT NULL,
            marca INTEGER NOT NULL,
            PRIMARY KEY (placa),
            FOREIGN KEY(proprietario) REFERENCES Pessoa(cpf),
            FOREIGN KEY(marca) REFERENCES Marca(id));'''
        cursor.execute(sql1)
        cursor.execute(sql2)
        cursor.execute(sql3)
        #efetivação do comando
        conexao.commit()
        print('Banco de dados ok')
    except conector.DatabaseError as err:
        print('Erro de banco de dados',err)
    finally:
        #fechamento das conexões
        if(conexao):
            cursor.close()
            conexao.close()

def inserir_registro():
    try:
        #abertura da conexão
        conexao = conector.connect('meu_banco.db')
        #aquisição de um cursor
        cursor = conexao.cursor()
        #execução de comandos SQL
        sql = '''INSERT INTO Pessoa (cpf, nome, nascimento, oculos)
            VALUES (10000000099, 'Maria', '1990-01-31', 0);
            INSERT INTO Pessoa (cpf, nome, nascimento, oculos)
            VALUES (20000000099,'José','1990-02-28',0);
            INSERT INTO Marca (nome, sigla) VALUES ('Marca A', 'MA');
            INSERT INTO Marca (nome, sigla) VALUES ('Marca B', 'MB');
            INSERT INTO Veiculo VALUES ('AAA0001', 2001, 'Prata', 1.0, 10000000099, 1);
            INSERT INTO Veiculo VALUES ('BAA0002', 2002, 'Preto', 1.4, 10000000099, 1);
            INSERT INTO Veiculo VALUES ('CAA0003', 2003, 'Branco', 2.0, 20000000099, 2);
            INSERT INTO Veiculo VALUES ('DAA0004', 2004, 'Azul', 2.2, 30000000099, 2);'''
        cursor.executescript(sql)
        #efetivação do comando
        conexao.commit()
        print('Registro inserido')
    except conector.DatabaseError as err:
        print('Erro de banco de dados',err)
    finally:
        #fechamento das conexões
        if(conexao):
            cursor.close()
            conexao.close()

#executar função
criar_tabela()
inserir_registro()
#encerrando
print("Fim do programa")
