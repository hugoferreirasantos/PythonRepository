#Aula 03 - exemplo_funcao.py
#Criar uma função que grave os números inteiros em um arquivo de texto
def gerarListaOrdenada():
    #Pede a digitação de um número mas como é string, converte-o
    quantidade = int(input('Informe a quantidade de elementos:'))
    arquivo = open('idsOrdenados.txt','w')
    for elemento in range(1,quantidade+1):
        arquivo.write(str(elemento) + '\n')
    arquivo.close()

#Criar função para ......
def nomedafuncao():


    
#executar a função
gerarListaOrdenada()


    
