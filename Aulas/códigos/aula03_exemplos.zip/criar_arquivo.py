#Aula 03 - criar_arquivo.py
#Criar um arquivo vazio
arq = open('teste.dat', 'w')
print (arq)
arq.close()
print('\nArquivo vazio criado com sucesso!')
