arquivo = open('idsOrdenados.txt','r')
conteudo = arquivo.read() 
print(conteudo)
