'''
Aula06_exemplo01.py
'''
#biblioteca
import sqlite3 as conector #apelido
def criar_tabela():
    #mensagem
    print('Abrindo uma conexão de BD')
    #abertura da conexão
    conexao = conector.connect('academia.db')
    #aquisição de um cursor
    cursor = conexao.cursor()
    #execução de comandos SQL
    sql = "create table cadastro (codigo integer, nome text, idade integer)"
    cursor.execute(sql)
    sql = "insert into cadastro (codigo, nome, idade) values (1284, 'Pedro de Oliveira', 32)"
    cursor.execute(sql)
    sql = "insert into cadastro (codigo, nome, idade) values (1309, 'Lúcia Machado', 37)"
    cursor.execute(sql)
    #efetivação do comando
    conexao.commit()
    #fechamento das conexões
    cursor.close()
    conexao.close()
    #encerrando
    print("Abra a pasta do programa e veja se o arquivo está lá !!!")
    print("Fim do programa")
#executar função
criar_tabela()
