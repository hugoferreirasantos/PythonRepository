'''
Aula06_exemplo02.py
'''
#biblioteca
import sqlite3 as conector #apelido
def alterar_tabela():
    #mensagem
    print('Abrindo uma conexão de BD')
    #abertura da conexão
    conexao = conector.connect('academia.db')
    #aquisição de um cursor
    cursor = conexao.cursor()
    #execução de comandos SQL
    sql = "ALTER TABLE cadastro ADD limite REAL;"
    cursor.execute(sql)
    #atualiza os registros com o campo adicionado
    sql = "UPDATE cadastro SET limite=1000;"
    cursor.execute(sql)
    #efetivação do comando
    conexao.commit()
    #fechamento das conexões
    cursor.close()
    conexao.close()
    #encerrando
    print("Tabela atualizada")
    print("Fim do programa")
#executar função
alterar_tabela()
