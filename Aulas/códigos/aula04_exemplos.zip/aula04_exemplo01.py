'''
Aula04_exemplo01.py

#variáveis
nome = "Ronaldo"
sobrenome = "Candido"
numero1 = 10
numero2 = 5
#exibir
print(nome + ' ' + sobrenome)
print(numero1 + numero2)
'''
#entrada de dados
x = int(input('Digite um número: '))
y = int(input('Digite outro número: '))
#operações matemáticas
print('Soma = ' + str(x + y))
print('Subtração = ' + str(x - y))
print('Multiplicação = ' + str(x * y))
print('Divisão = ' + str(x / y))

